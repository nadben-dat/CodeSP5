/*
This class needs to view a list of members
*/

import java.io.*; // for File
import java.util.Scanner;

public class MemberList{

  public static void main(String[] args) throws FileNotFoundException{
    
    //Create a Scanner that reads from the File
    Scanner input = new Scanner(new File("MemberList.txt"));
  
    //while loop with hasNext method
    while (input.hasNextLine()){
      String text = input.nextLine();
      System.out.println(text);
    }
  }
}