import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.File;
import java.io.FilenameFilter;
import java.io.PrintStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;

public class Filer {

   public static void main(String[] args) throws FileNotFoundException {
      Filer F1 = new Filer();
      ArrayList<String> filecontent = new ArrayList<String>();
      filecontent = F1.loadFile("medlem.txt");
   //   Result R1 = R1.getResult(filecontent);
   //F1.printList(filecontent);
      //F1.getResult(filecontent);
   //F1.writeFile("medlem2.txt",F1.loadFile("medlem.txt"));
   //F1.printList(F1.loadFile("medlem.txt"));
   }

   public void printList(ArrayList<String> somelist){
      for (int i = 0; i<somelist.size(); i++){
         System.out.println((i+1)+": "+ somelist.get(i));
      } 
   }


   public ArrayList<String> loadFile(String somefile)throws FileNotFoundException {
   //load file into arraylist of string
      ArrayList<String> somelist = new ArrayList<String>();        
   
      try {
      //open file for reading
         Scanner input = new Scanner(new File (somefile));
      
         while (input.hasNext())
         {
            somelist.add(input.nextLine());
         }
      }
      catch (FileNotFoundException e) {}    
   
      return(somelist);
   }

   private boolean canRead(String somefile){
      File f = new File(somefile);
      return f.canRead();
   }

   public void writeFile(String somefile, ArrayList<String> somelist)
   throws FileNotFoundException {
   //open existing file for writing or make new one
      try {
         PrintStream somestream;
         FileOutputStream fos = new FileOutputStream(somefile);//, true);
         if (canRead(somefile))
         {
         //we have a file we can use
         //System.out.println("we have a file we can use");
            somestream = new PrintStream(fos);
         }
         else
         {
         //cant read the file so lets assume it doesnt exist
            somestream = new PrintStream(fos);
         }
      //write something in file
         for (int i = 0; i<somelist.size(); i++){
            String outputline = String.join(" ", somelist.get(i));
            somestream.println(outputline);
         }    
      }
      catch (FileNotFoundException e) {} 
   }
      
//    public void listfiles (){
//       File folder = new File("Events");
//       File[] listOfFiles = folder.listFiles();
//    
//       for (int i = 0; i < listOfFiles.length; i++) {
//          if (listOfFiles[i].isFile()) {
//             System.out.println("File " + listOfFiles[i].getName());
//          } else if (listOfFiles[i].isDirectory()) {
//             System.out.println("Directory " + listOfFiles[i].getName());
//          }
//       }
//    
//    }      


    public File[] listFiles( String dirName){
        File dir = new File(dirName);

        return dir.listFiles(new FilenameFilter() { 
                 public boolean accept(File dir, String filename)
                      { return filename.endsWith(".mbr"); }
        } );

    }


}