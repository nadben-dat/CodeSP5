package kon;




import java.util.Scanner;

public class Member{
   private String name;
   private int age;
   private String adress;
   private String tlf;
   private String email;
   private String activity;


   Scanner input = new Scanner(System.in);
  

   public Member(){
   
   }
   public void createMember(){
   
      while (true){
         try{
         
            System.out.println("\n |Create member|");
         
            System.out.print("Name; ");
            String name = input.nextLine();
         
            System.out.print("Age: ");
            int age = input.nextInt();
           
            
         
            System.out.print("Adress: ");
            String adress = input.nextLine();
         
            System.out.print("tlfNr: ");
            String tlf = input.nextLine();
         
            System.out.print("Email: ");
            String email = input.nextLine();
            
            System.out.print("Activity: ***************");
            String activity = input.nextLine();
            if (activity == "Motionist") activity = "Motionist";
            else activity = "Konkurrencesv�mmer";
            
            
         
            this.name = name;
            this.age = age;
            this.adress = adress;
            this.tlf = tlf;
            this.email = email;
            this.activity = activity;
         
         
            break;
         }
         catch(Exception e){
         
            System.out.println("Wrong input! Please try again");
         
         }
      }
      
   }
   public String memberInfo(){
      
      String info = "Name: " + name + "Age: " + age + "Adress: " + adress + "Phone: " + tlf + "Email: "+ email + "Activity: "+ activity + "\n\n";
      
      return info;
   //}
  // public int getAge(){
     // return age;
   //}
   //public String getAge(){
      //return name;
   //}
   //public String getAge(){
      //return adress;
   }


    protected int getAge() {
       return 0;
    }
}