package kon;

public class Motionst extends Member{

   public void Motion(){
      System.out.println("I be swimmin' all day");
   }

}