package kon;

public class CompetetiveSwimmer extends Member{
   Kontingent CreateK = new Kontingent();
   public void kontingent(){

      if (18 >= super.getAge()) {
         if (!(!(super.getAge() <= 18) && !(getAge() >= 60))) {
            final double kontingentPension = CreateK.getKontingentPension();
         } else {
            CreateK.getKontingentSenior();
         }
      } else {
         CreateK.getKontingentJunior();
      }

   }


 protected int getAge() {

    return 0;
 }

}
