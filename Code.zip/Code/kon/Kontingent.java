package kon;

public class Kontingent{

   double kontingentJunior = 1000;
   double kontingentSenior = 1600;
   double kontingentPension;
   
   public Kontingent(){
      kontingentJunior = 1000;
      kontingentSenior = 1600;
      kontingentPension = kontingentSenior * 0.75;
   
   
   }
   public double getKontingentJunior(){
      return kontingentJunior;
   
   }
   public double getKontingentSenior(){
      return kontingentSenior;
   }
   public double getKontingentPension(){
      return kontingentPension;
   }


}